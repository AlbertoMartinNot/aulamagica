<?php
session_destroy();

  ?>