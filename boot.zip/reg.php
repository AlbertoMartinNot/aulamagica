<?php
	$c=mysqli_connect("localhost","root","","test");

	$sq="SELECT nombre FROM usuarios";
	$sql="SELECT ID_usu FROM usuarios";

	$res=mysqli_query($c,$sq);
	$res2=mysqli_query($c,$sql);
	$reg=mysqli_fetch_assoc($res);
	$reg2=mysqli_fetch_assoc($res2);
	if($reg['nombre']==$_POST['usu']){
		echo "El nombre de usuario ya existe";

	}else if($reg2['ID_usu']==$_POST['dni']){
		echo "El dni está repetido";
	}else{

	$sql="INSERT INTO usuarios (ID_usu,nombre,pass,email) VALUES (?,?,?,?)";
	$res=mysqli_prepare($c,$sql);
	$ok=mysqli_stmt_bind_param($res,"ssss",$_POST['dni'],$_POST['usu'],MD5($_POST['psw']),$_POST['correo']);
	$ok=mysqli_stmt_execute($res);

	header("location:mayia.html");
	}
?>